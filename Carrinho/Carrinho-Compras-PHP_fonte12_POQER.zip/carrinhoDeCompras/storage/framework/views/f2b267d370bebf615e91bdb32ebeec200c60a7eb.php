<?php $__env->startPush('scripts'); ?>
    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>
<?php $__env->stopPush(); ?>